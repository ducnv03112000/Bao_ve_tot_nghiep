/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ketnoi;

import java.sql.Connection;
import java.sql.DriverManager;
import menuAdmin.menu;

/**
 *
 * @author Admin
 */
public class ketnoi {
    public static Connection getConnection(){
         
        Connection cons = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            cons = DriverManager.getConnection(
                    "jdbc:sqlserver://DESKTOP-0NA3I34:1433;databaseName=petshopp1","sa","123");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cons;
    }

    public static void main(String[] args) {
         System.out.println(getConnection());
        
        
    }

    
    
    

    
    
   
    
}
