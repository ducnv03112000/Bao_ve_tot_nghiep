/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ketnoi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import menuAdmin.danhgiajpannel;

/**
 *
 * @author Admin
 */
public class danhgiaDAOimpl implements danhgiaDAO{
    private danhgiajpannel danhgia;

    @Override
    public List<danhgiajpannel> getList() {
        Connection cons = ketnoi.getConnection();
        String sql = "SELECT * FROM danhgia";
        List<danhgiajpannel> list = new ArrayList<>();
        try {
            PreparedStatement ps = (PreparedStatement) cons.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                danhgiajpannel dg = new danhgiajpannel();
              dg.setmadanhgia(rs.getString("madanhgia"));
              dg.setmakhachhang(rs.getString("makh"));
              dg.settenkhachhang(rs.getString("tenkh"));
              dg.setsanpham(rs.getString("sanpham"));
              dg.setmasanpham(rs.getString("masp"));
              dg.setdanhgia(rs.getString("danhgia"));
              
                
                list.add(danhgia);
            }
            ps.close();
            cons.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
     public static void main(String[] args) {
        danhgiaDAO dgDAO = new danhgiaDAOimpl();
        System.out.println(dgDAO.getList());
    }
    }
    

