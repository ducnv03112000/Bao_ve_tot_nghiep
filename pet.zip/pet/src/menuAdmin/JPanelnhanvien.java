/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menuAdmin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ketnoi.ketnoi;

/**
 *
 * @author Admin
 */
public class JPanelnhanvien extends javax.swing.JPanel {
    ArrayList<NV> list = new ArrayList<>();
    DefaultTableModel model = new DefaultTableModel();

    Connection cn;

    int current = 0;
    int index;
    /**
     * Creates new form JPanelnhanvien
     */
    public JPanelnhanvien() {
        initComponents();
        cn = ketnoi.ketnoi();
        if (cn == null) {
            System.out.println("Kết nối thất bại");
            System.exit(0);
        }
    }
    public void LoadComBox() {
        try {
            String sql1 = "select manv from  nhanvien";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql1);
            while (rs.next()) {
                cbomv.addItem(rs.getString("manv"));
            }

        } catch (Exception e) {
        }

    }
    public void LoadComBox2() {
        try {
            String sql1 = "select chucvu from  nhanvien";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql1);
            while (rs.next()) {
                cbbChucVu_NhanVien.addItem(rs.getString("chucvu"));
            }

        } catch (Exception e) {
        }

    }
    private void loadDbToTable() {
        try {
            String sql = "select * from nhanvien";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            list.clear();
            while (rs.next()) {
                String manv = rs.getString("manv");
                String tennv = rs.getString("tennv");
                String ngaysinh = rs.getString("ngaysinh");
                String sodienthoai = rs.getString("dienthoai");
                String chucvu = rs.getString("chucvu");
                String diachi = rs.getString("diachi");
                boolean gender = rs.getBoolean("gioitinh");
                String email = rs.getString("email");

                NV v = new NV(manv, tennv, ngaysinh,gender , email, chucvu,diachi, sodienthoai);
                list.add(v);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "lỗi" + e);

        }
    }
    public void filltoTable() {
        model.setRowCount(0);
        for (NV s : list) 
        {
            model.addRow(new Object[]{s.getManv(), s.getTennv(), s.getNgaysinh(), s.isGender(), s.getEmail(), s.getChucvu(), s.getDiachi(), s.getPhone()});
        }
    }
    public void showDetail(int index) {
        NV nv = list.get(index);

        txtMaNhanVien_NhanVien.setText(nv.getManv());
        txtTenNhanVien_NhanVien.setText(nv.getTennv());
        txtNgaySinh_NhanVien.setText(nv.getNgaysinh());
        txtSoDT_NhanVien.setText(nv.getPhone());
        cbbChucVu_NhanVien.setSelectedItem(nv.getChucvu());
        txtDiaChi_NhanVien.setText(nv.getDiachi());
        if (nv.isGender() == true) {
            rbtnNam_NhanVien.setSelected(true);
        } else {
            rbtnNu_NhanVien.setSelected(true);
        }
        txtEmail_NhanVien.setText(nv.getEmail());
    }
    public boolean check() {
        if (txtMaNhanVien_NhanVien.getText().equals("") || txtTenNhanVien_NhanVien.getText().equals("") || txtNgaySinh_NhanVien.getText().equals("")
                || txtSoDT_NhanVien.getText().equals("") || txtDiaChi_NhanVien.getText().equals("") || txtEmail_NhanVien.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Hãy nhập đủ dữ liệu ");
            return false;

        } else if (!rbtnNam_NhanVien.isSelected() && !rbtnNu_NhanVien.isSelected()) {
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn giới tính");
            return false;
        }
        return true;
    }
    public boolean selectItem() {
        try {
            String sql = "SELECT * FROM nhanvien WHERE manv = ?";
            String ma = (String) cbomv.getSelectedItem();
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, ma);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                txtMaNhanVien_NhanVien.setText(rs.getString("manv"));
                txtTenNhanVien_NhanVien.setText(rs.getString("tennv"));
                txtNgaySinh_NhanVien.setText(rs.getString("ngaysinh"));
                txtSoDT_NhanVien.setText(rs.getString("dienthoai"));
                txtDiaChi_NhanVien.setText(rs.getString("diachi"));
                buttonGroup1.clearSelection();
                txtEmail_NhanVien.setText(rs.getString("email"));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanelNhanVien = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblNhanVien = new javax.swing.JTable();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        lblTenNhanVien_NhanVien = new javax.swing.JLabel();
        lblMaNhanVien_NhanVien = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        txtTenNhanVien_NhanVien = new javax.swing.JTextField();
        txtMaNhanVien_NhanVien = new javax.swing.JTextField();
        rbtnNam_NhanVien = new javax.swing.JRadioButton();
        rbtnNu_NhanVien = new javax.swing.JRadioButton();
        txtNgaySinh_NhanVien = new javax.swing.JTextField();
        lblDiaChi_NhanVien = new javax.swing.JLabel();
        lblSDT_NhanVien = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        btnThem_NhanVien = new javax.swing.JButton();
        btnSua_NhanVien = new javax.swing.JButton();
        btnXoa_NhanVien = new javax.swing.JButton();
        txtDiaChi_NhanVien = new javax.swing.JTextField();
        txtSoDT_NhanVien = new javax.swing.JTextField();
        cbbChucVu_NhanVien = new javax.swing.JComboBox<>();
        lblemail_NhanVien = new javax.swing.JLabel();
        txtEmail_NhanVien = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btntimkiem = new javax.swing.JButton();
        cbomv = new javax.swing.JComboBox<>();

        jPanelNhanVien.setBackground(new java.awt.Color(204, 255, 255));
        jPanelNhanVien.setPreferredSize(new java.awt.Dimension(1030, 600));
        jPanelNhanVien.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                jPanelNhanVienComponentShown(evt);
            }
        });

        tblNhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã Nhân Viên", "Tên Nhân Viên", "Ngày Sinh ", "Giới Tính", "Email", "Chức Vụ", "Địa Chỉ", "Số ĐT"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhanVienMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tblNhanVien);

        jPanel15.setBackground(new java.awt.Color(102, 255, 255));
        jPanel15.setBorder(javax.swing.BorderFactory.createCompoundBorder());

        jPanel16.setBackground(new java.awt.Color(102, 255, 255));

        lblTenNhanVien_NhanVien.setText("Tên Nhân Viên");

        lblMaNhanVien_NhanVien.setText("Mã Nhân Viên");

        jLabel45.setText("Ngày Sinh");

        jLabel46.setText("Giới Tính");

        txtMaNhanVien_NhanVien.setEditable(false);

        buttonGroup1.add(rbtnNam_NhanVien);
        rbtnNam_NhanVien.setText("Nam");
        rbtnNam_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnNam_NhanVienActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtnNu_NhanVien);
        rbtnNu_NhanVien.setText("Nữ");

        txtNgaySinh_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNgaySinh_NhanVienActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblMaNhanVien_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel45)
                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTenNhanVien_NhanVien))
                .addGap(23, 23, 23)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtTenNhanVien_NhanVien, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtMaNhanVien_NhanVien, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(rbtnNam_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                        .addComponent(rbtnNu_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4))
                    .addComponent(txtNgaySinh_NhanVien))
                .addGap(0, 17, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMaNhanVien_NhanVien)
                    .addComponent(txtMaNhanVien_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTenNhanVien_NhanVien)
                    .addComponent(txtTenNhanVien_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(txtNgaySinh_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel46)
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rbtnNam_NhanVien)
                        .addComponent(rbtnNu_NhanVien)))
                .addContainerGap(82, Short.MAX_VALUE))
        );

        lblDiaChi_NhanVien.setText("Địa Chỉ");

        lblSDT_NhanVien.setText("Số ĐT");

        jLabel52.setText("Chức Vụ");

        btnThem_NhanVien.setText("Thêm");
        btnThem_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThem_NhanVienActionPerformed(evt);
            }
        });

        btnSua_NhanVien.setText("Sửa");
        btnSua_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSua_NhanVienActionPerformed(evt);
            }
        });

        btnXoa_NhanVien.setText("Xóa");
        btnXoa_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoa_NhanVienActionPerformed(evt);
            }
        });

        txtDiaChi_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDiaChi_NhanVienActionPerformed(evt);
            }
        });

        txtSoDT_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSoDT_NhanVienActionPerformed(evt);
            }
        });

        cbbChucVu_NhanVien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblemail_NhanVien.setText("Email");

        txtEmail_NhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmail_NhanVienActionPerformed(evt);
            }
        });

        jButton1.setText("Đổi Ảnh");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblDiaChi_NhanVien)
                                    .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(22, 22, 22))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                                .addComponent(lblSDT_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDiaChi_NhanVien)
                            .addComponent(txtSoDT_NhanVien)
                            .addComponent(cbbChucVu_NhanVien, 0, 169, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(lblemail_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtEmail_NhanVien)))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(btnThem_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSua_NhanVien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnXoa_NhanVien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(jButton1)))
                .addGap(123, 123, 123))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnThem_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(cbbChucVu_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel52)))
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblDiaChi_NhanVien)
                                    .addComponent(txtDiaChi_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblSDT_NhanVien)
                                    .addComponent(txtSoDT_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(btnSua_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblemail_NhanVien)
                            .addComponent(txtEmail_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnXoa_NhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(39, 39, 39))))
        );

        btntimkiem.setText("Search");
        btntimkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntimkiemActionPerformed(evt);
            }
        });

        cbomv.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "chọn nhân viên" }));
        cbomv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbomvActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelNhanVienLayout = new javax.swing.GroupLayout(jPanelNhanVien);
        jPanelNhanVien.setLayout(jPanelNhanVienLayout);
        jPanelNhanVienLayout.setHorizontalGroup(
            jPanelNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelNhanVienLayout.createSequentialGroup()
                .addGroup(jPanelNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelNhanVienLayout.createSequentialGroup()
                        .addGap(168, 168, 168)
                        .addComponent(cbomv, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btntimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 1001, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelNhanVienLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap(299, Short.MAX_VALUE))
        );
        jPanelNhanVienLayout.setVerticalGroup(
            jPanelNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelNhanVienLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanelNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btntimkiem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbomv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanelNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, 1300, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 639, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanelNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, 639, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jPanelNhanVienComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanelNhanVienComponentShown

    }//GEN-LAST:event_jPanelNhanVienComponentShown

    private void txtEmail_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmail_NhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmail_NhanVienActionPerformed

    private void txtSoDT_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSoDT_NhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSoDT_NhanVienActionPerformed

    private void txtDiaChi_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDiaChi_NhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDiaChi_NhanVienActionPerformed

    private void btnXoa_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoa_NhanVienActionPerformed
        try {
            current = tblNhanVien.getSelectedRow();
            if (current < 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn lại");
                return;
            }
            if (list.size() <= 0) {
                JOptionPane.showMessageDialog(this, "Không còn gì để xóa");
                return;
            }
            int hoi = JOptionPane.showConfirmDialog(this, "Bạn muốn xóa Nhan Vien"
                + ":" + txtMaNhanVien_NhanVien.getText());
            if (hoi != JOptionPane.YES_OPTION) {
                return;
            }
            String sql = "delete from nhanvien where manv=?";
            java.sql.PreparedStatement pst = cn.prepareStatement(sql);
            pst.setString(1, txtMaNhanVien_NhanVien.getText());
            int n = pst.executeUpdate();
            if (n > 0) {
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                list.remove(current);
                model.removeRow(current);
                if (list.size() > 0) {
                    if (current == list.size()) {
                        current--;
                    }
                    showDetail(current);
                } else {
//                    clearFrom();
                }
            }

        } catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(this, "Error");
        }
        //        String MaNhanVien = txtMaNhanVien_NhanVien.getText();
        //        if (!MaNhanVien.equals("")) {
            //            String cautruyvan = "delete NhanVien where MaNhanVien=" + MaNhanVien;
            //            String ctvKiemThu = "select count(MaHoaDon) as SoHoaDon"
            //            + " from NhanVien,HoaDon where NhanVien.MaNhanVien=HoaDon.MaNhanVien and NhanVien.MaNhanVien=" + MaNhanVien;
            //            ResultSet rs1 = huyphpk00628_asm_gd2.HUYPHPK00628_ASM_GD2.connection.ExcuteQueryGetTable(ctvKiemThu);
            //            String ctvKiemThu2 = "select count(MaPhieuNhap) as SoPhieuNhap"
            //            + " from NhanVien,PhieuNhap where NhanVien.MaNhanVien=PhieuNhap.MaNhanVien and NhanVien.MaNhanVien=" + MaNhanVien;
            //            ResultSet rs2 = huyphpk00628_asm_gd2.HUYPHPK00628_ASM_GD2.connection.ExcuteQueryGetTable(ctvKiemThu2);
            //            int so1 = 0, so2 = 0;
            //
            //            try {
                //                if (rs1.next()) {
                    //                    so1 = rs1.getInt("SoHoaDon");
                    //                }
                //            } catch (SQLException ex) {
                //                System.out.println(ex.toString());
                //            }
            //            try {
                //
                //                if (rs2.next()) {
                    //                    so2 = rs2.getInt("SoPhieuNhap");
                    //                    if (rs2.getInt("SoPhieuNhap") == 0 && so1 == 0) {
                        //                        huyphpk00628_asm_gd2.HUYPHPK00628_ASM_GD2.connection.ExcuteQueryUpdateDB(cautruyvan);
                        //                        System.out.println("đã xóa");
                        //                        layDuLieuNhanVien();
                        //                        ResNhanVien();
                        //                    } else {
                        //                        ThongBao("không thể xóa bởi có trong " + so1 + " hóa đơn \n và có trong "
                            //                            + so2 + "   phiếu Nhập", "báo lỗi", 2);
                        //                    }
                    //                }
                //
                //            } catch (SQLException ex) {
                //                System.out.println(ex.toString());
                //            }
            //        } else {
            //            ThongBao("bạn chưa nhập mã nhân viên", "lỗi khi cố xóa nhân viên mà chưa click chuột vô anh ấy", 2);
            //        }
    }//GEN-LAST:event_btnXoa_NhanVienActionPerformed

    private void btnSua_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSua_NhanVienActionPerformed
try {

            String manv = txtMaNhanVien_NhanVien.getText();
                String tennv = txtTenNhanVien_NhanVien.getText();
                String ngaysinh = txtNgaySinh_NhanVien.getText();
                String sodienthoai = txtSoDT_NhanVien.getText();
                String chucvu = (String) cbbChucVu_NhanVien.getSelectedItem();
                String diachi = txtDiaChi_NhanVien.getText();
                String email = txtEmail_NhanVien.getText();
                boolean gender;
                if (rbtnNam_NhanVien.isSelected()) {
                    gender = true;
                } else {
                    gender = false;
                }
            NV v = new NV(manv, tennv, ngaysinh, sodienthoai, chucvu, diachi, gender,email);
            String sql = "update nhanvien "
            + "set tennv=?,ngaysinh=?,dienthoai=?,chucvu=?,diachi=?,gioitinh=?,email=?"
            + "where MaNV=?";
            PreparedStatement pst = cn.prepareStatement(sql);
                pst.setString(1, manv);
                pst.setString(2, tennv);
                pst.setString(3, ngaysinh);
                pst.setString(8, sodienthoai);
                pst.setString(6, chucvu);
                pst.setString(7, diachi);
                pst.setString(5, email);
                pst.setBoolean(4, gender);
            pst.executeUpdate();
            list.add(v);
            filltoTable();
            JOptionPane.showMessageDialog(this, "sua thanh cong");
        } catch (Exception e) {
        }        
//        String MaNhanVien, TenNhanVien, NgaySinh, GioiTinh, NgayVaoLam, ChucVu, DiaChi, SoDT, GhiChu;
        //        MaNhanVien = txtMaNhanVien_NhanVien.getText();
        //        if (rbtnNam_NhanVien.isSelected()) {
            //            GioiTinh = "1";
            //        } else {
            //            GioiTinh = "0";
            //        }
        //        ChucVu = GetCbbSelected(cbbChucVu_NhanVien);
        //        TenNhanVien = txtTenNhanVien_NhanVien.getText();
        //        String ngay, thang, nam;
        //        ngay = cbbNgaySinh_NhanVien.getSelectedItem().toString();
        //        thang = cbbThangSinh_NhanVien.getSelectedItem().toString();
        //        nam = cbbNamSinh_NhanVien.getSelectedItem().toString();
        //        NgaySinh = nam + "-" + thang + "-" + ngay;
        //        String ngayv, thangv, namv;
        //        ngayv = cbbNgayVaoLam_NhanVien.getSelectedItem().toString();
        //        thangv = cbbThangVaoLam_NhanVien.getSelectedItem().toString();
        //        namv = cbbNamVaoLam_NhanVien.getSelectedItem().toString();
        //        NgayVaoLam = namv + "-" + thangv + "-" + ngayv;
        //        DiaChi = txtDiaChi_NhanVien.getText();
        //        SoDT = txtSoDT_NhanVien.getText();
        //        GhiChu = txtChuThich_NhanVien.getText();
        //        String cautruyvan = "update NhanVien set TenNhanVien=" + "N'" + TenNhanVien
        //        + "',NgaySinh='" + NgaySinh + "',GioiTinh=" + GioiTinh
        //        + ",NgayVaoLam='" + NgayVaoLam + "',ChucVu="
        //        + ChucVu + ",DiaChi=N'" + DiaChi + "',SoDT='" + SoDT + "',GhiChu=N'" + GhiChu + "'where MaNhanVien=" + MaNhanVien;
        //        boolean kiemtra = KiemTraNhapNhanVien(1);
        //        if (kiemtra) {
            //            HUYPHPK00628_ASM_GD2.connection.ExcuteQueryUpdateDB(cautruyvan);
            //            System.out.println("Đã sửa Thành Công");
            //        } else {
            //            ThongBao("Không thể sửa Nhân Viên", "lỗi", 2);
            //        }
        //        layDuLieuNhanVien();
    }//GEN-LAST:event_btnSua_NhanVienActionPerformed

    private void btnThem_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThem_NhanVienActionPerformed
if (check()) {
            try {

                String manv = txtMaNhanVien_NhanVien.getText();
                String tennv = txtTenNhanVien_NhanVien.getText();
                String ngaysinh = txtNgaySinh_NhanVien.getText();
                String sodienthoai = txtSoDT_NhanVien.getText();
                String chucvu = (String) cbbChucVu_NhanVien.getSelectedItem();
                String diachi = txtDiaChi_NhanVien.getText();
                String email = txtEmail_NhanVien.getText();
                boolean gender;
                if (rbtnNam_NhanVien.isSelected()) {
                    gender = true;
                } else {
                    gender = false;
                }
                NV v = new NV(manv, tennv, ngaysinh, sodienthoai, chucvu, diachi, gender,email);
                String sql = "insert into nhanvien values(?,?,?,?,?,?,?,?)";
                PreparedStatement pst = cn.prepareStatement(sql);
                pst.setString(1, manv);
                pst.setString(2, tennv);
                pst.setString(3, ngaysinh);
                pst.setString(8, sodienthoai);
                pst.setString(6, chucvu);
                pst.setString(7, diachi);
                pst.setString(5, email);
                pst.setBoolean(4, gender);
                int n = pst.executeUpdate();
                if (n > 0) {
                    JOptionPane.showMessageDialog(this, "Thêm dữ liệu thành công");
                    list.add(v);
                    model.addRow(new Object[]{manv, tennv, ngaysinh, sodienthoai, chucvu, diachi, gender});
                    current = list.size() - 1;
                    showDetail(current);
                }
                pst.close();
            } catch (Exception e) {
            }
        }        
//        String MaNhanVien, TenNhanVien, NgaySinh, GioiTinh, NgayVaoLam, ChucVu, DiaChi, SoDT, GhiChu;
        //        MaNhanVien = txtMaNhanVien_NhanVien.getText();
        //        if (rbtnNam_NhanVien.isSelected()) {
            //            GioiTinh = "1";
            //        } else {
            //            GioiTinh = "0";
            //        }
        //        ChucVu = GetCbbSelected(cbbChucVu_NhanVien);
        //        TenNhanVien = txtTenNhanVien_NhanVien.getText();
        //        String ngay, thang, nam;
        //        ngay = cbbNgaySinh_NhanVien.getSelectedItem().toString();
        //        thang = cbbThangSinh_NhanVien.getSelectedItem().toString();
        //        nam = cbbNamSinh_NhanVien.getSelectedItem().toString();
        //        NgaySinh = nam + "-" + thang + "-" + ngay;
        //        String ngayv, thangv, namv;
        //        ngayv = cbbNgayVaoLam_NhanVien.getSelectedItem().toString();
        //        thangv = cbbThangVaoLam_NhanVien.getSelectedItem().toString();
        //        namv = cbbNamVaoLam_NhanVien.getSelectedItem().toString();
        //        NgayVaoLam = namv + "-" + thangv + "-" + ngayv;
        //        DiaChi = txtDiaChi_NhanVien.getText();
        //        SoDT = txtSoDT_NhanVien.getText();
        //        GhiChu = txtChuThich_NhanVien.getText();
        //        String cautruyvan = "insert into NhanVien values(" + "N'" + TenNhanVien
        //        + "','" + NgaySinh + "'," + GioiTinh + ",'" + NgayVaoLam + "',"
        //        + ChucVu + ",N'" + DiaChi + "','" + SoDT + "',N'" + GhiChu + "')";
        //
        //        boolean kiemtra = KiemTraNhapNhanVien(0);
        //        if (kiemtra) {
            //            HUYPHPK00628_ASM_GD2.connection.ExcuteQueryUpdateDB(cautruyvan);
            //            System.out.println("Đã Thêm Thành Công");
            //            System.out.println(cautruyvan);
            //        } else {
            //            System.out.println("Thất Bại");
            //        }
        //        layDuLieuNhanVien();
    }//GEN-LAST:event_btnThem_NhanVienActionPerformed

    private void rbtnNam_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnNam_NhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnNam_NhanVienActionPerformed

    private void cbomvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbomvActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbomvActionPerformed

    private void txtNgaySinh_NhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNgaySinh_NhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNgaySinh_NhanVienActionPerformed

    private void btntimkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntimkiemActionPerformed
        // TODO add your handling code here:
        this.selectItem();
        
        
    }//GEN-LAST:event_btntimkiemActionPerformed

    private void tblNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhanVienMouseClicked
        // TODO add your handling code here:
        try {
            index = tblNhanVien.getSelectedRow();
            showDetail(index);
        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_tblNhanVienMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSua_NhanVien;
    private javax.swing.JButton btnThem_NhanVien;
    private javax.swing.JButton btnXoa_NhanVien;
    private javax.swing.JButton btntimkiem;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbbChucVu_NhanVien;
    private javax.swing.JComboBox<String> cbomv;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanelNhanVien;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JLabel lblDiaChi_NhanVien;
    private javax.swing.JLabel lblMaNhanVien_NhanVien;
    private javax.swing.JLabel lblSDT_NhanVien;
    private javax.swing.JLabel lblTenNhanVien_NhanVien;
    private javax.swing.JLabel lblemail_NhanVien;
    private javax.swing.JRadioButton rbtnNam_NhanVien;
    private javax.swing.JRadioButton rbtnNu_NhanVien;
    private javax.swing.JTable tblNhanVien;
    private javax.swing.JTextField txtDiaChi_NhanVien;
    private javax.swing.JTextField txtEmail_NhanVien;
    private javax.swing.JTextField txtMaNhanVien_NhanVien;
    private javax.swing.JTextField txtNgaySinh_NhanVien;
    private javax.swing.JTextField txtSoDT_NhanVien;
    private javax.swing.JTextField txtTenNhanVien_NhanVien;
    // End of variables declaration//GEN-END:variables
}
