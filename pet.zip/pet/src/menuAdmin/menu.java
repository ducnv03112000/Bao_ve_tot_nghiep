/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menuAdmin;

import bean.bean;
import controler.cmhcontroller;
import java.util.List;
import java.util.ArrayList;
import javax.accessibility.AccessibleRelation;
import javax.swing.JPanel;

/**
 *
 * @author Admin
 */
public class menu extends javax.swing.JFrame {

    /**
     * Creates new form menu
     */
    public menu() {
        initComponents();
        setTitle("Tên cửa hàng");
        
        cmhcontroller cmh = new cmhcontroller(jpnview);
        cmh.setView(jpntrangchu, jlbtrangchu);
        
        List<bean> listitem = new ArrayList<>();
        listitem.add(new bean("trangchu", jpntrangchu, jlbtrangchu));
        listitem.add(new bean("nhanvien", jpnnhanvien, jlbnhanvien));
        listitem.add(new bean("khachhang" ,jpnkhachhang ,jlbkhachhang));
        listitem.add(new bean("danhgia" ,jpndanhgia ,jlbdanhgia));
        listitem.add(new bean("sanpham" ,jpnsanpham ,jlbsanpham));
        listitem.add(new bean("phukien" ,jpnphukien ,jlbphukien));
        listitem.add(new bean("hoadơn" ,jpnhoadon ,jlbhoadon));
        listitem.add(new bean("thongke" ,jpnthongke ,jlbthongke));
        
          cmh.setEvent(listitem);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jpnmenu = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jpnnhanvien = new javax.swing.JPanel();
        jlbnhanvien = new javax.swing.JLabel();
        jpndanhgia = new javax.swing.JPanel();
        jlbdanhgia = new javax.swing.JLabel();
        jpnsanpham = new javax.swing.JPanel();
        jlbsanpham = new javax.swing.JLabel();
        jpnphukien = new javax.swing.JPanel();
        jlbphukien = new javax.swing.JLabel();
        jpnkhachhang = new javax.swing.JPanel();
        jlbkhachhang = new javax.swing.JLabel();
        jpnhoadon = new javax.swing.JPanel();
        jlbhoadon = new javax.swing.JLabel();
        jpnthongke = new javax.swing.JPanel();
        jlbthongke = new javax.swing.JLabel();
        jpntrangchu = new javax.swing.JPanel();
        jlbtrangchu = new javax.swing.JLabel();
        jpnview = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpnmenu.setBackground(new java.awt.Color(0, 51, 51));

        jPanel2.setBackground(new java.awt.Color(255, 153, 0));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Tên cửa hàng");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                .addContainerGap())
        );

        jpnnhanvien.setBackground(new java.awt.Color(0, 255, 0));

        jlbnhanvien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbnhanvien.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbnhanvien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/baseline_face_black_24dp.png"))); // NOI18N
        jlbnhanvien.setText("Nhân viên");

        javax.swing.GroupLayout jpnnhanvienLayout = new javax.swing.GroupLayout(jpnnhanvien);
        jpnnhanvien.setLayout(jpnnhanvienLayout);
        jpnnhanvienLayout.setHorizontalGroup(
            jpnnhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnnhanvienLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbnhanvien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnnhanvienLayout.setVerticalGroup(
            jpnnhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbnhanvien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpndanhgia.setBackground(new java.awt.Color(0, 255, 0));

        jlbdanhgia.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbdanhgia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbdanhgia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/outline_message_black_24dp.png"))); // NOI18N
        jlbdanhgia.setText("Đánh Giá");

        javax.swing.GroupLayout jpndanhgiaLayout = new javax.swing.GroupLayout(jpndanhgia);
        jpndanhgia.setLayout(jpndanhgiaLayout);
        jpndanhgiaLayout.setHorizontalGroup(
            jpndanhgiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpndanhgiaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbdanhgia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpndanhgiaLayout.setVerticalGroup(
            jpndanhgiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbdanhgia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpnsanpham.setBackground(new java.awt.Color(0, 255, 0));

        jlbsanpham.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbsanpham.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbsanpham.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/outline_fastfood_black_24dp.png"))); // NOI18N
        jlbsanpham.setText("Sản Phẩm");

        javax.swing.GroupLayout jpnsanphamLayout = new javax.swing.GroupLayout(jpnsanpham);
        jpnsanpham.setLayout(jpnsanphamLayout);
        jpnsanphamLayout.setHorizontalGroup(
            jpnsanphamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnsanphamLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbsanpham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnsanphamLayout.setVerticalGroup(
            jpnsanphamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbsanpham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpnphukien.setBackground(new java.awt.Color(0, 255, 0));

        jlbphukien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbphukien.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbphukien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/outline_beach_access_black_24dp.png"))); // NOI18N
        jlbphukien.setText("Phụ Kiện");

        javax.swing.GroupLayout jpnphukienLayout = new javax.swing.GroupLayout(jpnphukien);
        jpnphukien.setLayout(jpnphukienLayout);
        jpnphukienLayout.setHorizontalGroup(
            jpnphukienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnphukienLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbphukien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnphukienLayout.setVerticalGroup(
            jpnphukienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbphukien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpnkhachhang.setBackground(new java.awt.Color(0, 255, 0));

        jlbkhachhang.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbkhachhang.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbkhachhang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/outline_sentiment_satisfied_alt_black_24dp.png"))); // NOI18N
        jlbkhachhang.setText("Khách Hàng");

        javax.swing.GroupLayout jpnkhachhangLayout = new javax.swing.GroupLayout(jpnkhachhang);
        jpnkhachhang.setLayout(jpnkhachhangLayout);
        jpnkhachhangLayout.setHorizontalGroup(
            jpnkhachhangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnkhachhangLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbkhachhang, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnkhachhangLayout.setVerticalGroup(
            jpnkhachhangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbkhachhang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpnhoadon.setBackground(new java.awt.Color(0, 255, 0));

        jlbhoadon.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbhoadon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbhoadon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/outline_text_snippet_black_24dp.png"))); // NOI18N
        jlbhoadon.setText("Hóa Đơn");

        javax.swing.GroupLayout jpnhoadonLayout = new javax.swing.GroupLayout(jpnhoadon);
        jpnhoadon.setLayout(jpnhoadonLayout);
        jpnhoadonLayout.setHorizontalGroup(
            jpnhoadonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnhoadonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbhoadon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnhoadonLayout.setVerticalGroup(
            jpnhoadonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnhoadonLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jlbhoadon))
        );

        jpnthongke.setBackground(new java.awt.Color(0, 255, 0));

        jlbthongke.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbthongke.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbthongke.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/outline_stairs_black_24dp.png"))); // NOI18N
        jlbthongke.setText("Thống Kê");

        javax.swing.GroupLayout jpnthongkeLayout = new javax.swing.GroupLayout(jpnthongke);
        jpnthongke.setLayout(jpnthongkeLayout);
        jpnthongkeLayout.setHorizontalGroup(
            jpnthongkeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnthongkeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbthongke, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnthongkeLayout.setVerticalGroup(
            jpnthongkeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbthongke, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpntrangchu.setBackground(new java.awt.Color(0, 255, 0));

        jlbtrangchu.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbtrangchu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbtrangchu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/baseline_supervised_user_circle_black_24dp.png"))); // NOI18N
        jlbtrangchu.setText("Trang Chủ");

        javax.swing.GroupLayout jpntrangchuLayout = new javax.swing.GroupLayout(jpntrangchu);
        jpntrangchu.setLayout(jpntrangchuLayout);
        jpntrangchuLayout.setHorizontalGroup(
            jpntrangchuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpntrangchuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbtrangchu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpntrangchuLayout.setVerticalGroup(
            jpntrangchuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbtrangchu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jpnmenuLayout = new javax.swing.GroupLayout(jpnmenu);
        jpnmenu.setLayout(jpnmenuLayout);
        jpnmenuLayout.setHorizontalGroup(
            jpnmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jpnmenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnnhanvien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpndanhgia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnsanpham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnphukien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnkhachhang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnhoadon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnthongke, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpntrangchu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jpnmenuLayout.setVerticalGroup(
            jpnmenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnmenuLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpntrangchu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnnhanvien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnkhachhang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpndanhgia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnsanpham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnphukien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnhoadon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnthongke, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jpnview.setPreferredSize(new java.awt.Dimension(700, 550));

        javax.swing.GroupLayout jpnviewLayout = new javax.swing.GroupLayout(jpnview);
        jpnview.setLayout(jpnviewLayout);
        jpnviewLayout.setHorizontalGroup(
            jpnviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        jpnviewLayout.setVerticalGroup(
            jpnviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jpnmenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jpnview, javax.swing.GroupLayout.DEFAULT_SIZE, 900, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnmenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jpnview, javax.swing.GroupLayout.DEFAULT_SIZE, 598, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel jlbdanhgia;
    private javax.swing.JLabel jlbhoadon;
    private javax.swing.JLabel jlbkhachhang;
    private javax.swing.JLabel jlbnhanvien;
    private javax.swing.JLabel jlbphukien;
    private javax.swing.JLabel jlbsanpham;
    private javax.swing.JLabel jlbthongke;
    private javax.swing.JLabel jlbtrangchu;
    private javax.swing.JPanel jpndanhgia;
    private javax.swing.JPanel jpnhoadon;
    private javax.swing.JPanel jpnkhachhang;
    private javax.swing.JPanel jpnmenu;
    private javax.swing.JPanel jpnnhanvien;
    private javax.swing.JPanel jpnphukien;
    private javax.swing.JPanel jpnsanpham;
    private javax.swing.JPanel jpnthongke;
    private javax.swing.JPanel jpntrangchu;
    private javax.swing.JPanel jpnview;
    // End of variables declaration//GEN-END:variables
}
