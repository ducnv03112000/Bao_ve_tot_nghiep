/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menuAdmin;

/**
 *
 * @author Admin
 */
public class NV {
    String manv, tennv, ngaysinh, phone, chucvu,diachi,email;
    boolean gender;
    public NV(){
    
}
    public NV(String manv, String tennv, String ngaysinh, String phone, String chucvu,String diachi,String email, boolean gender) {
        this.manv = manv;
        this.tennv = tennv;
       this.ngaysinh = ngaysinh;
        this.phone = phone;
        this.chucvu = chucvu;
        this.diachi=diachi;
        this.email = email;
        this.gender = gender;
    }

    NV(String manv, String tennv, String ngaysinh, String sodienthoai, String chucvu, String diachi, boolean gender, String email) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    NV(String manv, String tennv, String ngaysinh, boolean gender, String email, String chucvu, String diachi, String sodienthoai) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getManv() {
        return manv;
    }

    public void setManv(String manv) {
        this.manv = manv;
    }

    public String getTennv() {
        return tennv;
    }

    public void setTennv(String tennv) {
        this.tennv = tennv;
    }

    public String getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(String ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getChucvu() {
        return chucvu;
    }

    public void setChucvu(String chucvu) {
        this.chucvu = chucvu;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }
    
}
