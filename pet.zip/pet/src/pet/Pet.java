
package pet;

import menuAdmin.menu;


public class Pet {

    
    public static void main(String[] args) {
        new menu().setVisible(true);
        
    }
    
}
